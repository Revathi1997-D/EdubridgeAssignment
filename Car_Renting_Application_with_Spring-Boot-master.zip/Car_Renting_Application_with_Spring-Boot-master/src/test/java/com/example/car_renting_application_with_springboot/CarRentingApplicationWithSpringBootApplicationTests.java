package com.example.car_renting_application_with_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentingApplicationWithSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
